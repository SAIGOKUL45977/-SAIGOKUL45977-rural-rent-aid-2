import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Tractor, 
  Wrench, 
  User, 
  Wheat, 
  Phone, 
  ArrowRight,
  Globe,
  ChevronDown,
  MapPin,
  Camera,
  Upload,
  IndianRupee,
  CreditCard,
  ArrowLeft
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useLanguage, languageNames, type Language } from '@/contexts/LanguageContext';
import { useAuth, type UserRole } from '@/contexts/AuthContext';
import heroImage from '@/assets/hero-farm.jpg';
import { toast } from 'sonner';

const roleIcons = {
  farmer: Wheat,
  owner: Tractor,
  repair: Wrench,
  driver: User,
};

const roleColors = {
  farmer: 'bg-primary',
  owner: 'bg-secondary',
  repair: 'bg-accent',
  driver: 'bg-earth',
};

const roleBgColors = {
  farmer: 'hover:border-primary/50',
  owner: 'hover:border-secondary/50',
  repair: 'hover:border-accent/50',
  driver: 'hover:border-earth/50',
};

type Step = 'role' | 'mobile' | 'otp' | 'details' | 'additional';

interface RegistrationData {
  name: string;
  mobile: string;
  gender: 'male' | 'female' | 'other';
  age: string;
  aadhaar: string;
  pinCode: string;
  location: { lat: number; lng: number } | null;
  profilePhoto?: string;
  servicePhotos?: string[];
  pricePerHour?: string;
  pricePerDay?: string;
  drivingLicense?: string;
}

export default function LoginPage() {
  const { t, language, setLanguage } = useLanguage();
  const { register } = useAuth();
  const navigate = useNavigate();
  
  const [selectedRole, setSelectedRole] = useState<UserRole | null>(null);
  const [mobile, setMobile] = useState('');
  const [otp, setOtp] = useState('');
  const [step, setStep] = useState<Step>('role');
  const [showLanguageMenu, setShowLanguageMenu] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [locationLoading, setLocationLoading] = useState(false);

  const [formData, setFormData] = useState<RegistrationData>({
    name: '',
    mobile: '',
    gender: 'male',
    age: '',
    aadhaar: '',
    pinCode: '',
    location: null,
  });

  const roles: { key: UserRole; label: string }[] = [
    { key: 'farmer', label: t('farmer') },
    { key: 'owner', label: t('machineryOwner') },
    { key: 'repair', label: t('repairShop') },
    { key: 'driver', label: t('driver') },
  ];

  const handleSendOtp = () => {
    if (mobile.length >= 10) {
      setFormData(prev => ({ ...prev, mobile }));
      toast.success('OTP sent to +91 ' + mobile);
      setStep('otp');
    }
  };

  const handleVerifyOtp = async () => {
    if (otp === '123456') {
      toast.success('Mobile verified!');
      setStep('details');
    } else {
      toast.error('Invalid OTP. Use 123456 for demo');
    }
  };

  const getCurrentLocation = () => {
    setLocationLoading(true);
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setFormData(prev => ({
            ...prev,
            location: {
              lat: position.coords.latitude,
              lng: position.coords.longitude
            }
          }));
          toast.success('Location detected!');
          setLocationLoading(false);
        },
        () => {
          toast.error('Could not get location. Please enable GPS.');
          setLocationLoading(false);
        }
      );
    } else {
      toast.error('Geolocation not supported');
      setLocationLoading(false);
    }
  };

  const formatAadhaar = (value: string) => {
    const digits = value.replace(/\D/g, '').slice(0, 12);
    return digits.replace(/(\d{4})(?=\d)/g, '$1-');
  };

  const handleDetailsSubmit = async () => {
    if (!formData.name || !formData.age || !formData.aadhaar || !formData.pinCode) {
      toast.error('Please fill all required fields');
      return;
    }
    if (formData.aadhaar.replace(/\D/g, '').length !== 12) {
      toast.error('Aadhaar must be 12 digits');
      return;
    }
    
    if (selectedRole === 'farmer') {
      await completeRegistration();
    } else {
      setStep('additional');
    }
  };

  const completeRegistration = async () => {
    setIsLoading(true);
    const success = await register({
      name: formData.name,
      mobile: formData.mobile,
      role: selectedRole!,
      gender: formData.gender,
      age: parseInt(formData.age),
      aadhaar: formData.aadhaar,
      pinCode: formData.pinCode,
      location: formData.location,
      profilePhoto: formData.profilePhoto,
      servicePhotos: formData.servicePhotos,
      pricePerHour: formData.pricePerHour ? parseFloat(formData.pricePerHour) : undefined,
      pricePerDay: formData.pricePerDay ? parseFloat(formData.pricePerDay) : undefined,
      drivingLicense: formData.drivingLicense,
    });
    
    if (success) {
      toast.success('Registration successful!');
      navigate('/dashboard');
    } else {
      toast.error('Registration failed');
    }
    setIsLoading(false);
  };

  const handleBack = () => {
    if (step === 'mobile') setStep('role');
    else if (step === 'otp') setStep('mobile');
    else if (step === 'details') setStep('otp');
    else if (step === 'additional') setStep('details');
  };

  const needsDrivingLicense = selectedRole === 'owner' || selectedRole === 'driver';

  const getStepTitle = () => {
    switch (step) {
      case 'role': return t('register');
      case 'mobile': return t('mobileNumber');
      case 'otp': return t('verifyOTP');
      case 'details': return 'Basic Details';
      case 'additional': return 'Service Details';
    }
  };

  return (
    <div className="min-h-screen flex flex-col relative overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src={heroImage} 
          alt="Agricultural field" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-foreground/70 via-foreground/50 to-foreground/80" />
      </div>

      {/* Language Selector */}
      <div className="absolute top-4 right-4 z-20">
        <div className="relative">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowLanguageMenu(!showLanguageMenu)}
            className="bg-background/20 backdrop-blur-sm text-background hover:bg-background/30 border border-background/30"
          >
            <Globe className="w-4 h-4 mr-2" />
            {languageNames[language]}
            <ChevronDown className="w-4 h-4 ml-2" />
          </Button>
          
          {showLanguageMenu && (
            <div className="absolute top-full right-0 mt-2 bg-card rounded-lg shadow-lg border overflow-hidden animate-scale-in z-30">
              {(Object.entries(languageNames) as [Language, string][]).map(([code, name]) => (
                <button
                  key={code}
                  onClick={() => {
                    setLanguage(code);
                    setShowLanguageMenu(false);
                  }}
                  className={`w-full px-4 py-3 text-left hover:bg-muted transition-colors ${
                    language === code ? 'bg-primary/10 text-primary font-medium' : ''
                  }`}
                >
                  {name}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 flex flex-col items-center justify-center p-4 z-10">
        {/* Logo & Title */}
        <div className="text-center mb-8 animate-fade-in">
          <div className="w-20 h-20 rounded-full bg-primary flex items-center justify-center mx-auto mb-4 shadow-lg">
            <Tractor className="w-10 h-10 text-primary-foreground" />
          </div>
          <h1 className="text-3xl font-bold text-background mb-2">{t('appName')}</h1>
          <p className="text-background/80">{t('tagline')}</p>
        </div>

        {/* Login Card */}
        <Card variant="elevated" className="w-full max-w-md animate-slide-up">
          <CardHeader>
            <div className="flex items-center gap-2">
              {step !== 'role' && (
                <Button variant="ghost" size="icon" onClick={handleBack} className="shrink-0">
                  <ArrowLeft className="h-5 w-5" />
                </Button>
              )}
              <CardTitle className="text-center flex-1">
                {getStepTitle()}
              </CardTitle>
            </div>
          </CardHeader>
          
          <CardContent className="space-y-4">
            {/* Step 1: Role Selection */}
            {step === 'role' && (
              <div className="grid grid-cols-2 gap-3">
                {roles.map(({ key, label }, index) => {
                  const Icon = roleIcons[key];
                  return (
                    <button
                      key={key}
                      onClick={() => {
                        setSelectedRole(key);
                        setStep('mobile');
                      }}
                      className={`p-4 rounded-xl border-2 transition-all duration-300 hover:shadow-md animate-slide-up ${roleBgColors[key]} ${
                        selectedRole === key ? 'border-primary bg-primary/5' : 'border-border'
                      }`}
                      style={{ animationDelay: `${index * 100}ms` }}
                    >
                      <div className={`w-12 h-12 rounded-full ${roleColors[key]} flex items-center justify-center mx-auto mb-3`}>
                        <Icon className="w-6 h-6 text-primary-foreground" />
                      </div>
                      <p className="font-medium text-center text-sm">{label}</p>
                    </button>
                  );
                })}
              </div>
            )}

            {/* Step 2: Mobile Number */}
            {step === 'mobile' && (
              <div className="space-y-4 animate-fade-in">
                <div className="flex items-center gap-2 p-3 bg-muted rounded-lg mb-2">
                  {selectedRole && (
                    <>
                      <div className={`w-8 h-8 rounded-full ${roleColors[selectedRole]} flex items-center justify-center`}>
                        {React.createElement(roleIcons[selectedRole], { className: 'w-4 h-4 text-primary-foreground' })}
                      </div>
                      <span className="font-medium text-sm">{roles.find(r => r.key === selectedRole)?.label}</span>
                    </>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <div className="h-12 px-4 flex items-center bg-muted rounded-lg border-2 border-input">
                    <span className="text-muted-foreground font-medium">+91</span>
                  </div>
                  <Input
                    type="tel"
                    placeholder="Enter mobile number"
                    value={mobile}
                    onChange={(e) => setMobile(e.target.value.replace(/\D/g, '').slice(0, 10))}
                    className="flex-1"
                  />
                </div>
                
                <Button 
                  variant="hero" 
                  className="w-full" 
                  onClick={handleSendOtp}
                  disabled={mobile.length < 10}
                >
                  {t('sendOTP')}
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            )}

            {/* Step 3: OTP Verification */}
            {step === 'otp' && (
              <div className="space-y-4 animate-fade-in">
                <div className="flex items-center gap-2 mb-2">
                  <Phone className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm text-muted-foreground">+91 {mobile}</span>
                </div>
                
                <Input
                  type="text"
                  placeholder="Enter 6-digit OTP"
                  value={otp}
                  onChange={(e) => setOtp(e.target.value.replace(/\D/g, '').slice(0, 6))}
                  className="text-center text-2xl tracking-widest font-mono"
                  maxLength={6}
                />
                
                <p className="text-xs text-muted-foreground text-center">
                  Demo: Enter 123456 to continue
                </p>
                
                <Button 
                  variant="hero" 
                  className="w-full" 
                  onClick={handleVerifyOtp}
                  disabled={otp.length < 6}
                >
                  {t('verifyOTP')}
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            )}

            {/* Step 4: Basic Details */}
            {step === 'details' && (
              <div className="space-y-4 animate-fade-in max-h-[55vh] overflow-y-auto pr-1">
                {/* Name */}
                <div className="space-y-2">
                  <Label>Full Name *</Label>
                  <Input
                    placeholder="Enter your full name"
                    value={formData.name}
                    onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  />
                </div>

                {/* Gender */}
                <div className="space-y-2">
                  <Label>Gender *</Label>
                  <div className="flex gap-2">
                    {(['male', 'female', 'other'] as const).map((g) => (
                      <Button
                        key={g}
                        type="button"
                        variant={formData.gender === g ? 'default' : 'outline'}
                        size="sm"
                        className="flex-1 capitalize"
                        onClick={() => setFormData(prev => ({ ...prev, gender: g }))}
                      >
                        {g}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Age */}
                <div className="space-y-2">
                  <Label>Age *</Label>
                  <Input
                    type="number"
                    placeholder="Enter your age"
                    value={formData.age}
                    onChange={(e) => setFormData(prev => ({ ...prev, age: e.target.value }))}
                    min="18"
                    max="100"
                  />
                </div>

                {/* Aadhaar */}
                <div className="space-y-2">
                  <Label>Aadhaar Card Number *</Label>
                  <Input
                    placeholder="XXXX-XXXX-XXXX"
                    value={formData.aadhaar}
                    onChange={(e) => setFormData(prev => ({ 
                      ...prev, 
                      aadhaar: formatAadhaar(e.target.value) 
                    }))}
                  />
                </div>

                {/* PIN Code */}
                <div className="space-y-2">
                  <Label>PIN Code *</Label>
                  <Input
                    type="text"
                    placeholder="Enter 6-digit PIN code"
                    value={formData.pinCode}
                    onChange={(e) => setFormData(prev => ({ 
                      ...prev, 
                      pinCode: e.target.value.replace(/\D/g, '').slice(0, 6) 
                    }))}
                  />
                </div>

                {/* Location */}
                <div className="space-y-2">
                  <Label>Current Location</Label>
                  <Button
                    type="button"
                    variant="outline"
                    className="w-full justify-start"
                    onClick={getCurrentLocation}
                    disabled={locationLoading}
                  >
                    <MapPin className="h-4 w-4 mr-2" />
                    {locationLoading 
                      ? 'Detecting...' 
                      : formData.location 
                        ? `Lat: ${formData.location.lat.toFixed(4)}, Lng: ${formData.location.lng.toFixed(4)}`
                        : 'Detect My Location'
                    }
                  </Button>
                </div>

                <Button 
                  variant="hero" 
                  className="w-full mt-4" 
                  onClick={handleDetailsSubmit}
                >
                  {selectedRole === 'farmer' ? 'Complete Registration' : 'Next: Service Details'}
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            )}

            {/* Step 5: Additional Details (for non-farmers) */}
            {step === 'additional' && (
              <div className="space-y-4 animate-fade-in max-h-[55vh] overflow-y-auto pr-1">
                {/* Profile Photo */}
                <div className="space-y-2">
                  <Label>Profile Photo *</Label>
                  <label className="border-2 border-dashed border-border rounded-lg p-4 text-center hover:border-primary transition-colors cursor-pointer block">
                    <Camera className="h-6 w-6 mx-auto text-muted-foreground mb-2" />
                    <p className="text-sm text-muted-foreground">Tap to upload photo</p>
                    <input 
                      type="file" 
                      accept="image/*" 
                      className="hidden" 
                      onChange={(e) => {
                        if (e.target.files?.[0]) {
                          setFormData(prev => ({ ...prev, profilePhoto: URL.createObjectURL(e.target.files![0]) }));
                          toast.success('Photo uploaded!');
                        }
                      }}
                    />
                  </label>
                  {formData.profilePhoto && (
                    <div className="w-16 h-16 rounded-full overflow-hidden mx-auto border-2 border-primary">
                      <img src={formData.profilePhoto} alt="Profile" className="w-full h-full object-cover" />
                    </div>
                  )}
                </div>

                {/* Service/Machinery Photos */}
                <div className="space-y-2">
                  <Label>
                    {selectedRole === 'owner' && 'Machinery Photos'}
                    {selectedRole === 'repair' && 'Shop Photos'}
                    {selectedRole === 'driver' && 'Experience Photos'}
                  </Label>
                  <label className="border-2 border-dashed border-border rounded-lg p-4 text-center hover:border-primary transition-colors cursor-pointer block">
                    <Upload className="h-6 w-6 mx-auto text-muted-foreground mb-2" />
                    <p className="text-sm text-muted-foreground">Upload service photos</p>
                    <input type="file" accept="image/*" multiple className="hidden" />
                  </label>
                </div>

                {/* Pricing */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label>Price/Hour (₹)</Label>
                    <div className="relative">
                      <IndianRupee className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        type="number"
                        placeholder="500"
                        className="pl-9"
                        value={formData.pricePerHour}
                        onChange={(e) => setFormData(prev => ({ ...prev, pricePerHour: e.target.value }))}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Price/Day (₹)</Label>
                    <div className="relative">
                      <IndianRupee className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        type="number"
                        placeholder="3000"
                        className="pl-9"
                        value={formData.pricePerDay}
                        onChange={(e) => setFormData(prev => ({ ...prev, pricePerDay: e.target.value }))}
                      />
                    </div>
                  </div>
                </div>

                {/* Driving License (for owners and drivers only) */}
                {needsDrivingLicense && (
                  <div className="space-y-2">
                    <Label>Driving License Number *</Label>
                    <div className="relative">
                      <CreditCard className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder="Enter license number"
                        className="pl-9"
                        value={formData.drivingLicense}
                        onChange={(e) => setFormData(prev => ({ ...prev, drivingLicense: e.target.value }))}
                      />
                    </div>
                    <p className="text-xs text-muted-foreground">Required for verification</p>
                  </div>
                )}

                <Button 
                  variant="hero" 
                  className="w-full mt-4" 
                  onClick={completeRegistration}
                  disabled={isLoading || (needsDrivingLicense && !formData.drivingLicense)}
                >
                  {isLoading ? 'Registering...' : 'Complete Registration'}
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Footer hint */}
        <p className="mt-6 text-background/80 text-sm animate-fade-in text-center">
          {t('selectRole')} • {t('tagline')}
        </p>
      </div>
    </div>
  );
}
