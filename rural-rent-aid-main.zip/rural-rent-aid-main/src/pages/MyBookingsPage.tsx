import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Calendar, MapPin, Clock, Tractor, Wrench, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';

// Mock bookings data
const mockBookings = [
  {
    id: 'BK001',
    type: 'machinery',
    name: 'John Deere 5050D',
    owner: 'Suresh Reddy',
    date: '2024-12-18',
    time: '09:00 AM',
    duration: '4 hours',
    location: 'Warangal',
    amount: 2000,
    status: 'upcoming',
    image: 'https://images.unsplash.com/photo-1605152276897-4f618f831968?w=400'
  },
  {
    id: 'BK002',
    type: 'driver',
    name: 'Raju Singh',
    date: '2024-12-15',
    time: '06:00 AM',
    duration: '1 day',
    location: 'Warangal',
    amount: 800,
    status: 'completed',
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400'
  },
  {
    id: 'BK003',
    type: 'repair',
    name: 'Kisan Agri Services',
    date: '2024-12-10',
    time: '10:00 AM',
    duration: '2 hours',
    location: 'Warangal',
    amount: 600,
    status: 'completed',
    image: 'https://images.unsplash.com/photo-1486262715619-67b85e0b08d3?w=400'
  },
];

export default function MyBookingsPage() {
  const { t } = useLanguage();
  const { user } = useAuth();
  const navigate = useNavigate();

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'machinery':
        return <Tractor className="w-5 h-5" />;
      case 'repair':
        return <Wrench className="w-5 h-5" />;
      case 'driver':
        return <User className="w-5 h-5" />;
      default:
        return <Calendar className="w-5 h-5" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'upcoming':
        return 'bg-primary/20 text-primary';
      case 'completed':
        return 'bg-leaf/20 text-leaf';
      case 'cancelled':
        return 'bg-destructive/20 text-destructive';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  const upcomingBookings = mockBookings.filter(b => b.status === 'upcoming');
  const pastBookings = mockBookings.filter(b => b.status !== 'upcoming');

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-primary text-primary-foreground p-4 sticky top-0 z-30">
        <div className="flex items-center gap-3">
          <Button
            variant="ghost"
            size="icon-sm"
            onClick={() => navigate('/dashboard')}
            className="text-primary-foreground hover:bg-primary-foreground/20"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-xl font-bold">{t('myBookings')}</h1>
        </div>
      </header>

      <main className="p-4 space-y-6">
        {/* Upcoming Bookings */}
        {upcomingBookings.length > 0 && (
          <section>
            <h2 className="text-lg font-semibold mb-3 flex items-center gap-2">
              <Clock className="w-5 h-5 text-primary" />
              Upcoming Bookings
            </h2>
            <div className="space-y-3">
              {upcomingBookings.map((booking) => (
                <Card key={booking.id} variant="interactive" className="overflow-hidden">
                  <CardContent className="p-0">
                    <div className="flex gap-4">
                      <img 
                        src={booking.image} 
                        alt={booking.name}
                        className="w-24 h-24 object-cover"
                      />
                      <div className="flex-1 py-3 pr-3">
                        <div className="flex items-start justify-between mb-1">
                          <div className="flex items-center gap-2">
                            {getTypeIcon(booking.type)}
                            <h3 className="font-semibold">{booking.name}</h3>
                          </div>
                          <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${getStatusColor(booking.status)}`}>
                            {booking.status}
                          </span>
                        </div>
                        <div className="text-sm text-muted-foreground space-y-1">
                          <div className="flex items-center gap-1">
                            <Calendar className="w-3.5 h-3.5" />
                            <span>{booking.date} • {booking.time}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <MapPin className="w-3.5 h-3.5" />
                            <span>{booking.location}</span>
                          </div>
                        </div>
                        <p className="text-primary font-bold mt-1">₹{booking.amount}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </section>
        )}

        {/* Past Bookings */}
        {pastBookings.length > 0 && (
          <section>
            <h2 className="text-lg font-semibold mb-3 text-muted-foreground">Past Bookings</h2>
            <div className="space-y-3">
              {pastBookings.map((booking) => (
                <Card key={booking.id} className="overflow-hidden opacity-80">
                  <CardContent className="p-0">
                    <div className="flex gap-4">
                      <img 
                        src={booking.image} 
                        alt={booking.name}
                        className="w-24 h-24 object-cover grayscale"
                      />
                      <div className="flex-1 py-3 pr-3">
                        <div className="flex items-start justify-between mb-1">
                          <div className="flex items-center gap-2">
                            {getTypeIcon(booking.type)}
                            <h3 className="font-semibold">{booking.name}</h3>
                          </div>
                          <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${getStatusColor(booking.status)}`}>
                            {booking.status}
                          </span>
                        </div>
                        <div className="text-sm text-muted-foreground space-y-1">
                          <div className="flex items-center gap-1">
                            <Calendar className="w-3.5 h-3.5" />
                            <span>{booking.date} • {booking.time}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <MapPin className="w-3.5 h-3.5" />
                            <span>{booking.location}</span>
                          </div>
                        </div>
                        <p className="font-bold mt-1">₹{booking.amount}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </section>
        )}

        {/* Empty State */}
        {mockBookings.length === 0 && (
          <div className="text-center py-12">
            <Calendar className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">No Bookings Yet</h3>
            <p className="text-muted-foreground mb-4">Start by booking machinery, repair services, or drivers</p>
            <Button variant="hero" onClick={() => navigate('/dashboard')}>
              Browse Services
            </Button>
          </div>
        )}
      </main>
    </div>
  );
}
