import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Search, 
  User, 
  Globe, 
  Tractor, 
  Wrench, 
  Users, 
  MapPin,
  Star,
  Clock,
  ChevronDown,
  Menu,
  X,
  Bell,
  Calendar
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { useLanguage, languageNames, type Language } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import heroImage from '@/assets/hero-farm.jpg';

// Mock data
const mockMachinery = [
  {
    id: '1',
    name: 'John Deere 5050D',
    type: 'Tractor',
    owner: 'Suresh Reddy',
    pricePerHour: 500,
    pricePerDay: 4000,
    location: 'Warangal',
    distance: '5 km',
    rating: 4.8,
    available: true,
    image: 'https://images.unsplash.com/photo-1605152276897-4f618f831968?w=400'
  },
  {
    id: '2',
    name: 'Mahindra 575 DI',
    type: 'Tractor',
    owner: 'Venkat Rao',
    pricePerHour: 450,
    pricePerDay: 3500,
    location: 'Karimnagar',
    distance: '8 km',
    rating: 4.5,
    available: true,
    image: 'https://images.unsplash.com/photo-1530267981375-f0de937f5f13?w=400'
  },
  {
    id: '3',
    name: 'Combine Harvester',
    type: 'Harvester',
    owner: 'Ramesh Kumar',
    pricePerHour: 1200,
    pricePerDay: 10000,
    location: 'Nizamabad',
    distance: '12 km',
    rating: 4.9,
    available: false,
    image: 'https://images.unsplash.com/photo-1574943320219-553eb213f72d?w=400'
  },
];

const mockRepairShops = [
  {
    id: '1',
    name: 'Kisan Agri Services',
    services: ['Engine Repair', 'Tyre Change', 'Oil Service'],
    chargesPerHour: 300,
    location: 'Warangal',
    distance: '3 km',
    rating: 4.7,
    image: 'https://images.unsplash.com/photo-1486262715619-67b85e0b08d3?w=400'
  },
  {
    id: '2',
    name: 'Sri Lakshmi Repairs',
    services: ['Full Service', 'Parts Replacement', 'Welding'],
    chargesPerHour: 250,
    location: 'Hanamkonda',
    distance: '6 km',
    rating: 4.4,
    image: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400'
  },
];

const mockDrivers = [
  {
    id: '1',
    name: 'Raju Singh',
    experience: 10,
    chargesPerDay: 800,
    location: 'Warangal',
    distance: '2 km',
    rating: 4.9,
    verified: true,
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400'
  },
  {
    id: '2',
    name: 'Prasad Reddy',
    experience: 7,
    chargesPerDay: 700,
    location: 'Kazipet',
    distance: '5 km',
    rating: 4.6,
    verified: true,
    image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400'
  },
];

type TabType = 'machinery' | 'repair' | 'drivers';

export default function Dashboard() {
  const { t, language, setLanguage } = useLanguage();
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  
  const [activeTab, setActiveTab] = useState<TabType>('machinery');
  const [searchQuery, setSearchQuery] = useState('');
  const [showLanguageMenu, setShowLanguageMenu] = useState(false);
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const tabs = [
    { key: 'machinery' as TabType, icon: Tractor, label: t('machinery') },
    { key: 'repair' as TabType, icon: Wrench, label: t('repairShops') },
    { key: 'drivers' as TabType, icon: Users, label: t('drivers') },
  ];

  const handleBooking = (itemId: string, type: string) => {
    navigate(`/booking/${type}/${itemId}`);
  };

  return (
    <div className="min-h-screen bg-background flex">
      {/* Mobile Sidebar Overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-foreground/50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Vertical Sidebar */}
      <aside className={`fixed lg:static inset-y-0 left-0 z-50 w-20 bg-primary flex flex-col items-center py-6 gap-4 transition-transform duration-300 ${
        sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
      }`}>
        {/* Logo */}
        <div className="w-12 h-12 rounded-full bg-primary-foreground/20 flex items-center justify-center mb-4">
          <Tractor className="w-6 h-6 text-primary-foreground" />
        </div>
        
        {/* Navigation Icons */}
        {tabs.map(({ key, icon: Icon, label }) => (
          <button
            key={key}
            onClick={() => {
              setActiveTab(key);
              setSidebarOpen(false);
            }}
            className={`w-14 h-14 rounded-xl flex flex-col items-center justify-center gap-1 transition-all duration-300 ${
              activeTab === key
                ? 'bg-primary-foreground text-primary shadow-md'
                : 'text-primary-foreground/70 hover:bg-primary-foreground/10'
            }`}
            title={label}
          >
            <Icon className="w-6 h-6" />
            <span className="text-[10px] font-medium">{label.slice(0, 6)}</span>
          </button>
        ))}

        <div className="flex-1" />

        {/* Bookings Icon */}
        <button
          onClick={() => navigate('/bookings')}
          className="w-14 h-14 rounded-xl flex flex-col items-center justify-center gap-1 text-primary-foreground/70 hover:bg-primary-foreground/10 transition-all"
          title={t('myBookings')}
        >
          <Calendar className="w-6 h-6" />
          <span className="text-[10px] font-medium">Bookings</span>
        </button>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-h-screen">
        {/* Top Header */}
        <header className="bg-card border-b sticky top-0 z-30">
          <div className="flex items-center gap-3 p-4">
            {/* Mobile Menu Button */}
            <Button
              variant="ghost"
              size="icon-sm"
              className="lg:hidden"
              onClick={() => setSidebarOpen(true)}
            >
              <Menu className="w-5 h-5" />
            </Button>

            {/* Search Bar */}
            <div className="flex-1 relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input
                type="text"
                placeholder={t('search')}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-12 h-11"
              />
            </div>

            {/* Language Selector */}
            <div className="relative hidden sm:block">
              <Button
                variant="ghost"
                size="icon-sm"
                onClick={() => setShowLanguageMenu(!showLanguageMenu)}
              >
                <Globe className="w-5 h-5" />
              </Button>
              
              {showLanguageMenu && (
                <div className="absolute top-full right-0 mt-2 bg-card rounded-lg shadow-lg border overflow-hidden animate-scale-in z-50 min-w-[140px]">
                  {(Object.entries(languageNames) as [Language, string][]).map(([code, name]) => (
                    <button
                      key={code}
                      onClick={() => {
                        setLanguage(code);
                        setShowLanguageMenu(false);
                      }}
                      className={`w-full px-4 py-2.5 text-left text-sm hover:bg-muted transition-colors ${
                        language === code ? 'bg-primary/10 text-primary font-medium' : ''
                      }`}
                    >
                      {name}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Profile */}
            <div className="relative">
              <Button
                variant="ghost"
                size="icon-sm"
                onClick={() => setShowProfileMenu(!showProfileMenu)}
                className="rounded-full"
              >
                <div className="w-9 h-9 rounded-full bg-primary flex items-center justify-center">
                  <User className="w-5 h-5 text-primary-foreground" />
                </div>
              </Button>
              
              {showProfileMenu && (
                <div className="absolute top-full right-0 mt-2 bg-card rounded-lg shadow-lg border overflow-hidden animate-scale-in z-50 min-w-[180px]">
                  <div className="p-3 border-b">
                    <p className="font-medium">{user?.name || 'Guest'}</p>
                    <p className="text-sm text-muted-foreground">{user?.mobile || ''}</p>
                  </div>
                  <button
                    onClick={() => navigate('/profile')}
                    className="w-full px-4 py-2.5 text-left text-sm hover:bg-muted transition-colors flex items-center gap-2"
                  >
                    <User className="w-4 h-4" />
                    {t('profile')}
                  </button>
                  <button
                    onClick={() => {
                      logout();
                      navigate('/');
                    }}
                    className="w-full px-4 py-2.5 text-left text-sm hover:bg-muted transition-colors text-destructive"
                  >
                    {t('logout')}
                  </button>
                </div>
              )}
            </div>
          </div>
        </header>

        {/* Content Area */}
        <main className="flex-1 p-4 overflow-y-auto">
          {/* Welcome Section */}
          <div className="mb-6">
            <h1 className="text-2xl font-bold mb-1">
              {t('welcome')}, {user?.name?.split(' ')[0] || 'Guest'}! 👋
            </h1>
            <p className="text-muted-foreground">{t('tagline')}</p>
          </div>

          {/* Tab Content */}
          {activeTab === 'machinery' && (
            <div className="space-y-4">
              <h2 className="text-lg font-semibold">{t('availableMachinery')}</h2>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {mockMachinery.map((item, index) => (
                  <Card 
                    key={item.id} 
                    variant="interactive"
                    className="overflow-hidden animate-slide-up"
                    style={{ animationDelay: `${index * 100}ms` }}
                  >
                    <div className="relative h-40">
                      <img 
                        src={item.image} 
                        alt={item.name}
                        className="w-full h-full object-cover"
                      />
                      <div className={`absolute top-3 right-3 px-2 py-1 rounded-full text-xs font-medium ${
                        item.available 
                          ? 'bg-leaf text-leaf-foreground' 
                          : 'bg-destructive text-destructive-foreground'
                      }`}>
                        {item.available ? t('available') : t('notAvailable')}
                      </div>
                    </div>
                    <CardContent className="pt-4">
                      <h3 className="font-bold text-lg mb-1">{item.name}</h3>
                      <p className="text-sm text-muted-foreground mb-2">{item.type}</p>
                      
                      <div className="flex items-center gap-2 text-sm mb-2">
                        <User className="w-4 h-4 text-muted-foreground" />
                        <span>{item.owner}</span>
                      </div>
                      
                      <div className="flex items-center gap-2 text-sm mb-3">
                        <MapPin className="w-4 h-4 text-muted-foreground" />
                        <span>{item.location} • {item.distance}</span>
                      </div>
                      
                      <div className="flex items-center justify-between mb-4">
                        <div>
                          <span className="text-lg font-bold text-primary">₹{item.pricePerHour}</span>
                          <span className="text-sm text-muted-foreground">{t('perHour')}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Star className="w-4 h-4 fill-secondary text-secondary" />
                          <span className="font-medium">{item.rating}</span>
                        </div>
                      </div>
                      
                      <Button 
                        variant="hero" 
                        className="w-full"
                        onClick={() => handleBooking(item.id, 'machinery')}
                        disabled={!item.available}
                      >
                        {t('bookNow')}
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'repair' && (
            <div className="space-y-4">
              <h2 className="text-lg font-semibold">{t('nearbyRepairShops')}</h2>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {mockRepairShops.map((shop, index) => (
                  <Card 
                    key={shop.id} 
                    variant="interactive"
                    className="overflow-hidden animate-slide-up"
                    style={{ animationDelay: `${index * 100}ms` }}
                  >
                    <div className="relative h-40">
                      <img 
                        src={shop.image} 
                        alt={shop.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <CardContent className="pt-4">
                      <h3 className="font-bold text-lg mb-1">{shop.name}</h3>
                      
                      <div className="flex items-center gap-2 text-sm mb-2">
                        <MapPin className="w-4 h-4 text-muted-foreground" />
                        <span>{shop.location} • {shop.distance}</span>
                      </div>
                      
                      <div className="flex flex-wrap gap-1 mb-3">
                        {shop.services.slice(0, 3).map((service) => (
                          <span key={service} className="px-2 py-1 bg-muted rounded-md text-xs">
                            {service}
                          </span>
                        ))}
                      </div>
                      
                      <div className="flex items-center justify-between mb-4">
                        <div>
                          <span className="text-lg font-bold text-accent">₹{shop.chargesPerHour}</span>
                          <span className="text-sm text-muted-foreground">{t('perHour')}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Star className="w-4 h-4 fill-secondary text-secondary" />
                          <span className="font-medium">{shop.rating}</span>
                        </div>
                      </div>
                      
                      <Button 
                        variant="repair" 
                        className="w-full"
                        onClick={() => handleBooking(shop.id, 'repair')}
                      >
                        {t('bookNow')}
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'drivers' && (
            <div className="space-y-4">
              <h2 className="text-lg font-semibold">{t('availableDrivers')}</h2>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {mockDrivers.map((driver, index) => (
                  <Card 
                    key={driver.id} 
                    variant="interactive"
                    className="overflow-hidden animate-slide-up"
                    style={{ animationDelay: `${index * 100}ms` }}
                  >
                    <CardContent className="pt-5">
                      <div className="flex items-start gap-4 mb-4">
                        <img 
                          src={driver.image} 
                          alt={driver.name}
                          className="w-16 h-16 rounded-full object-cover"
                        />
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <h3 className="font-bold text-lg">{driver.name}</h3>
                            {driver.verified && (
                              <span className="px-2 py-0.5 bg-leaf/20 text-leaf text-xs rounded-full font-medium">
                                ✓ {t('verified')}
                              </span>
                            )}
                          </div>
                          <p className="text-sm text-muted-foreground">
                            {driver.experience} {t('years')} {t('experience')}
                          </p>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-2 text-sm mb-3">
                        <MapPin className="w-4 h-4 text-muted-foreground" />
                        <span>{driver.location} • {driver.distance}</span>
                      </div>
                      
                      <div className="flex items-center justify-between mb-4">
                        <div>
                          <span className="text-lg font-bold text-earth">₹{driver.chargesPerDay}</span>
                          <span className="text-sm text-muted-foreground">{t('perDay')}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Star className="w-4 h-4 fill-secondary text-secondary" />
                          <span className="font-medium">{driver.rating}</span>
                        </div>
                      </div>
                      
                      <Button 
                        variant="driver" 
                        className="w-full"
                        onClick={() => handleBooking(driver.id, 'driver')}
                      >
                        {t('bookNow')}
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
