import React, { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { 
  ArrowLeft, 
  Calendar, 
  Clock, 
  MapPin, 
  User, 
  CreditCard,
  Banknote,
  Check,
  Smartphone
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';

type PaymentMethod = 'cod' | 'upi' | 'card';

export default function BookingPage() {
  const { t } = useLanguage();
  const { user } = useAuth();
  const navigate = useNavigate();
  const { type, id } = useParams();
  
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [duration, setDuration] = useState(1);
  const [durationType, setDurationType] = useState<'hours' | 'days'>('hours');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('cod');
  const [isConfirming, setIsConfirming] = useState(false);
  const [bookingComplete, setBookingComplete] = useState(false);
  const [bookingId, setBookingId] = useState('');

  // Mock item data based on type
  const itemData = {
    machinery: {
      name: 'John Deere 5050D',
      owner: 'Suresh Reddy',
      ownerPhone: '+91 98765 43210',
      pricePerHour: 500,
      pricePerDay: 4000,
      location: 'Warangal, Telangana',
      image: 'https://images.unsplash.com/photo-1605152276897-4f618f831968?w=400'
    },
    repair: {
      name: 'Kisan Agri Services',
      owner: 'Service Manager',
      ownerPhone: '+91 87654 32109',
      pricePerHour: 300,
      pricePerDay: 2500,
      location: 'Warangal, Telangana',
      image: 'https://images.unsplash.com/photo-1486262715619-67b85e0b08d3?w=400'
    },
    driver: {
      name: 'Raju Singh',
      owner: 'Self',
      ownerPhone: '+91 76543 21098',
      pricePerHour: 100,
      pricePerDay: 800,
      location: 'Warangal, Telangana',
      image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400'
    }
  };

  const item = itemData[type as keyof typeof itemData] || itemData.machinery;
  
  const calculateTotal = () => {
    const price = durationType === 'hours' ? item.pricePerHour : item.pricePerDay;
    return price * duration;
  };

  const handleConfirmBooking = async () => {
    if (!date || !time) {
      toast.error('Please select date and time');
      return;
    }

    setIsConfirming(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const newBookingId = 'BK' + Date.now().toString().slice(-8);
    setBookingId(newBookingId);
    setIsConfirming(false);
    setBookingComplete(true);
    
    toast.success(t('bookingSuccess'));
  };

  if (bookingComplete) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card variant="elevated" className="w-full max-w-md text-center animate-scale-in">
          <CardContent className="pt-8 pb-6">
            <div className="w-20 h-20 rounded-full bg-leaf/20 flex items-center justify-center mx-auto mb-6">
              <Check className="w-10 h-10 text-leaf" />
            </div>
            
            <h1 className="text-2xl font-bold mb-2">{t('bookingConfirmed')}</h1>
            <p className="text-muted-foreground mb-6">{t('notificationSent')}</p>
            
            <div className="bg-muted rounded-lg p-4 mb-6">
              <p className="text-sm text-muted-foreground mb-1">{t('bookingId')}</p>
              <p className="text-xl font-mono font-bold text-primary">{bookingId}</p>
            </div>
            
            <div className="space-y-3 text-left mb-6">
              <div className="flex justify-between py-2 border-b">
                <span className="text-muted-foreground">Service</span>
                <span className="font-medium">{item.name}</span>
              </div>
              <div className="flex justify-between py-2 border-b">
                <span className="text-muted-foreground">Date & Time</span>
                <span className="font-medium">{date} at {time}</span>
              </div>
              <div className="flex justify-between py-2 border-b">
                <span className="text-muted-foreground">Duration</span>
                <span className="font-medium">{duration} {durationType === 'hours' ? t('hours') : t('days')}</span>
              </div>
              <div className="flex justify-between py-2 border-b">
                <span className="text-muted-foreground">{t('paymentMethod')}</span>
                <span className="font-medium capitalize">{paymentMethod === 'cod' ? t('cashOnDelivery') : paymentMethod.toUpperCase()}</span>
              </div>
              <div className="flex justify-between py-2">
                <span className="text-muted-foreground">{t('totalAmount')}</span>
                <span className="font-bold text-lg text-primary">₹{calculateTotal()}</span>
              </div>
            </div>
            
            <Button variant="hero" className="w-full" onClick={() => navigate('/dashboard')}>
              Back to Dashboard
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-primary text-primary-foreground p-4 sticky top-0 z-10">
        <div className="flex items-center gap-4">
          <Button 
            variant="ghost" 
            size="icon-sm" 
            onClick={() => navigate(-1)}
            className="text-primary-foreground hover:bg-primary-foreground/10"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-lg font-semibold">{t('bookingDetails')}</h1>
        </div>
      </header>

      <main className="p-4 max-w-2xl mx-auto space-y-4">
        {/* Service Info Card */}
        <Card className="overflow-hidden animate-slide-up">
          <div className="flex gap-4 p-4">
            <img 
              src={item.image} 
              alt={item.name}
              className="w-24 h-24 rounded-lg object-cover"
            />
            <div className="flex-1">
              <h2 className="font-bold text-lg mb-1">{item.name}</h2>
              <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                <User className="w-4 h-4" />
                <span>{item.owner}</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <MapPin className="w-4 h-4" />
                <span>{item.location}</span>
              </div>
            </div>
          </div>
        </Card>

        {/* Farmer Info */}
        <Card className="animate-slide-up" style={{ animationDelay: '100ms' }}>
          <CardHeader>
            <CardTitle className="text-base">Your Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between">
              <span className="text-muted-foreground">{t('fullName')}</span>
              <span className="font-medium">{user?.name || 'Guest User'}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">{t('mobileNumber')}</span>
              <span className="font-medium">{user?.mobile || '+91 XXXXX XXXXX'}</span>
            </div>
          </CardContent>
        </Card>

        {/* Date & Time Selection */}
        <Card className="animate-slide-up" style={{ animationDelay: '200ms' }}>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Calendar className="w-5 h-5" />
              {t('selectDate')} & {t('selectTime')}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm text-muted-foreground mb-1 block">{t('selectDate')}</label>
                <Input 
                  type="date" 
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  min={new Date().toISOString().split('T')[0]}
                />
              </div>
              <div>
                <label className="text-sm text-muted-foreground mb-1 block">{t('selectTime')}</label>
                <Input 
                  type="time" 
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                />
              </div>
            </div>
            
            <div>
              <label className="text-sm text-muted-foreground mb-2 block">{t('duration')}</label>
              <div className="flex gap-2">
                <div className="flex-1">
                  <Input 
                    type="number" 
                    value={duration}
                    onChange={(e) => setDuration(Math.max(1, parseInt(e.target.value) || 1))}
                    min={1}
                  />
                </div>
                <div className="flex rounded-lg overflow-hidden border">
                  <button
                    onClick={() => setDurationType('hours')}
                    className={`px-4 py-2 text-sm font-medium transition-colors ${
                      durationType === 'hours' 
                        ? 'bg-primary text-primary-foreground' 
                        : 'bg-background hover:bg-muted'
                    }`}
                  >
                    {t('hours')}
                  </button>
                  <button
                    onClick={() => setDurationType('days')}
                    className={`px-4 py-2 text-sm font-medium transition-colors ${
                      durationType === 'days' 
                        ? 'bg-primary text-primary-foreground' 
                        : 'bg-background hover:bg-muted'
                    }`}
                  >
                    {t('days')}
                  </button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Payment Method */}
        <Card className="animate-slide-up" style={{ animationDelay: '300ms' }}>
          <CardHeader>
            <CardTitle className="text-base">{t('paymentMethod')}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <button
              onClick={() => setPaymentMethod('cod')}
              className={`w-full flex items-center gap-4 p-4 rounded-lg border-2 transition-all ${
                paymentMethod === 'cod' 
                  ? 'border-primary bg-primary/5' 
                  : 'border-border hover:border-primary/50'
              }`}
            >
              <div className="w-12 h-12 rounded-full bg-leaf/20 flex items-center justify-center">
                <Banknote className="w-6 h-6 text-leaf" />
              </div>
              <div className="text-left flex-1">
                <p className="font-medium">{t('cashOnDelivery')}</p>
                <p className="text-sm text-muted-foreground">Pay when service is completed</p>
              </div>
              {paymentMethod === 'cod' && (
                <div className="w-6 h-6 rounded-full bg-primary flex items-center justify-center">
                  <Check className="w-4 h-4 text-primary-foreground" />
                </div>
              )}
            </button>

            <button
              onClick={() => setPaymentMethod('upi')}
              className={`w-full flex items-center gap-4 p-4 rounded-lg border-2 transition-all ${
                paymentMethod === 'upi' 
                  ? 'border-primary bg-primary/5' 
                  : 'border-border hover:border-primary/50'
              }`}
            >
              <div className="w-12 h-12 rounded-full bg-sky/20 flex items-center justify-center">
                <Smartphone className="w-6 h-6 text-sky" />
              </div>
              <div className="text-left flex-1">
                <p className="font-medium">{t('upi')}</p>
                <p className="text-sm text-muted-foreground">Google Pay, PhonePe, Paytm</p>
              </div>
              {paymentMethod === 'upi' && (
                <div className="w-6 h-6 rounded-full bg-primary flex items-center justify-center">
                  <Check className="w-4 h-4 text-primary-foreground" />
                </div>
              )}
            </button>

            <button
              onClick={() => setPaymentMethod('card')}
              className={`w-full flex items-center gap-4 p-4 rounded-lg border-2 transition-all ${
                paymentMethod === 'card' 
                  ? 'border-primary bg-primary/5' 
                  : 'border-border hover:border-primary/50'
              }`}
            >
              <div className="w-12 h-12 rounded-full bg-secondary/20 flex items-center justify-center">
                <CreditCard className="w-6 h-6 text-secondary" />
              </div>
              <div className="text-left flex-1">
                <p className="font-medium">{t('debitCard')} / {t('creditCard')}</p>
                <p className="text-sm text-muted-foreground">Visa, Mastercard, RuPay</p>
              </div>
              {paymentMethod === 'card' && (
                <div className="w-6 h-6 rounded-full bg-primary flex items-center justify-center">
                  <Check className="w-4 h-4 text-primary-foreground" />
                </div>
              )}
            </button>
          </CardContent>
        </Card>

        {/* Price Summary */}
        <Card className="bg-primary/5 border-primary/20 animate-slide-up" style={{ animationDelay: '400ms' }}>
          <CardContent className="pt-5">
            <div className="flex justify-between items-center mb-2">
              <span className="text-muted-foreground">
                ₹{durationType === 'hours' ? item.pricePerHour : item.pricePerDay} × {duration} {durationType === 'hours' ? t('hours') : t('days')}
              </span>
              <span className="font-medium">₹{calculateTotal()}</span>
            </div>
            <div className="flex justify-between items-center pt-3 border-t">
              <span className="font-semibold">{t('totalAmount')}</span>
              <span className="text-2xl font-bold text-primary">₹{calculateTotal()}</span>
            </div>
          </CardContent>
        </Card>

        {/* Confirm Button */}
        <Button 
          variant="hero" 
          size="xl"
          className="w-full animate-slide-up"
          style={{ animationDelay: '500ms' }}
          onClick={handleConfirmBooking}
          disabled={isConfirming || !date || !time}
        >
          {isConfirming ? t('loading') : t('confirmBooking')}
        </Button>
      </main>
    </div>
  );
}
