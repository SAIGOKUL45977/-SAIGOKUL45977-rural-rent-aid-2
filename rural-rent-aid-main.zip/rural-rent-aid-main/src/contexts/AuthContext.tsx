import React, { createContext, useContext, useState, ReactNode } from 'react';

export type UserRole = 'farmer' | 'owner' | 'repair' | 'driver';

interface User {
  id: string;
  name: string;
  mobile: string;
  role: UserRole;
  gender: 'male' | 'female' | 'other';
  age: number;
  aadhaar: string;
  pinCode: string;
  location: { lat: number; lng: number } | null;
  profilePhoto?: string;
  servicePhotos?: string[];
  pricePerHour?: number;
  pricePerDay?: number;
  drivingLicense?: string;
  isVerified: boolean;
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  login: (mobile: string, otp: string) => Promise<boolean>;
  register: (userData: Partial<User>) => Promise<boolean>;
  logout: () => void;
  updateUser: (data: Partial<User>) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);

  const login = async (mobile: string, otp: string): Promise<boolean> => {
    // Simulate login - in production, this would be an API call
    if (otp === '123456') {
      // Mock user data
      setUser({
        id: '1',
        name: 'Ramesh Kumar',
        mobile,
        role: 'farmer',
        gender: 'male',
        age: 35,
        aadhaar: '1234-5678-9012',
        pinCode: '500001',
        location: { lat: 17.385, lng: 78.4867 },
        isVerified: true,
      });
      return true;
    }
    return false;
  };

  const register = async (userData: Partial<User>): Promise<boolean> => {
    // Simulate registration
    setUser({
      id: Date.now().toString(),
      name: userData.name || '',
      mobile: userData.mobile || '',
      role: userData.role || 'farmer',
      gender: userData.gender || 'male',
      age: userData.age || 0,
      aadhaar: userData.aadhaar || '',
      pinCode: userData.pinCode || '',
      location: userData.location || null,
      profilePhoto: userData.profilePhoto,
      servicePhotos: userData.servicePhotos,
      pricePerHour: userData.pricePerHour,
      pricePerDay: userData.pricePerDay,
      drivingLicense: userData.drivingLicense,
      isVerified: false,
    });
    return true;
  };

  const logout = () => {
    setUser(null);
  };

  const updateUser = (data: Partial<User>) => {
    if (user) {
      setUser({ ...user, ...data });
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        login,
        register,
        logout,
        updateUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
